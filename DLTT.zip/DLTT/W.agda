{-# OPTIONS --safe #-}

module DLTT.W where

open import DLTT.Base
open import DLTT.Examples.Sum

private
  variable
    ℓ ℓ' : Level



module _
  {A : ltyp ℓ} {B : A ↦ finltyp}
  where
  compspWᵒ : (p : (Wᵒ A B) ．)
    → (p ∶ Wᵒ A B) ≡ elimW (λ x f Δ → x ∶ A ⨾ ⨂ (B .fst x) (B .snd x) Δ) p
  compspWᵒ f = refl


module _
  {A : ltyp ℓ} {(B , bs) : A ↦ finltyp}
  {Δ₀ : sply ℓ}
  {Δ₁ : {x : A ．} → B x ． → sply ℓ}
  where
  introWᵒ :
    ((a , _) : Δ₀ ⊩ A)
    → (f : (y : B a ．) → Δ₁ y ⊩ Wᵒ A (B , bs))
    → Δ₀ ⨾ ⨂ (B a) (bs a) Δ₁ ⊩ Wᵒ A (B , bs)
  introWᵒ (a , δ₀) f = sup a (λ x → f x .fst) , δ₀ ⨾ᶠ ⨂ᶠ (λ x → f x .snd)

module _
  {A : ltyp ℓ} {(B , bs) : A ↦ finltyp}
  {C : Wᵒ A (B , bs) ↦ ltyp}
  {c : (a : A ．) → (f : B a ． → Wᵒ A (B , bs) ．) → ((y : B a ．) → C (f y) ．) → C (sup a f) ．}
  {Δ₁ : A ． → sply ℓ}
  where
  elimWᵒ' :
    (c : (x : A ．) (f : B x ． → Wᵒ A (B , bs) ．) (g : (y : B x ．) → C (f y) ．) →
      (x ∶ A)  ⨾ Δ₁ x ⨾ ⨂ (B x) (bs x) (λ y → g y ∶ C (f y)) ⊩ C (sup x f))
    → (w : Wᵒ A (B , bs) ．)
    → w ∶ Wᵒ A (B , bs) ⨾ recW (λ a Δ' → Δ₁ a ⨾ ⨂ (B a) (bs a) Δ') w ⊩ C w
  elimWᵒ' c = elimW λ a f g → c a f (λ y → g y .fst) .fst , c a f (λ y → g y .fst) .snd
    ∘ (id ⨾ᶠ (id ⨾ᶠ (⨂ᶠ (λ x → g x .snd) ∘ ⨂lax) ∘ assoc' ∘ swap ⨾ᶠ id ∘ assoc) ∘ assoc')

  elimWᵒ :
    {Δ₀ : sply ℓ} 
    (c : (x : A ．) (f : B x ． → Wᵒ A (B , bs) ．) (g : (y : B x ．) → C (f y) ．) →
      (x ∶ A)  ⨾ Δ₁ x ⨾ ⨂ (B x) (bs x) (λ y → g y ∶ C (f y)) ⊩ C (sup x f))
    → ((p , _) : Δ₀ ⊩  Wᵒ A (B , bs))
    → Δ₀ ⨾ recW (λ a Δ' → Δ₁ a ⨾ ⨂ (B a) (bs a) Δ') p ⊩ C p
  elimWᵒ c (p , δ) = Coerce {A = C p} (δ ⨾ᶠ id) (elimWᵒ' c p )


module _
  {A : ltyp ℓ} {(B , bs) : A ↦ finltyp}
  {C : Wᵒ A (B , bs) ↦ ltyp}
  {c : (a : A ．) → (f : B a ． → Wᵒ A (B , bs) ．) → ((y : B a ．) → C (f y) ．) → C (sup a f) ．}
  {Δ₁ : A ． → sply ℓ}
  where
  compWᵒ :
    ({x : A ．} {f : B x ． → Wᵒ A (B , bs) ．} {g : (y : B x ．) → C (f y) ．} →
      (x ∶ A) ⨾ Δ₁ x ⨾ ⨂ (B x) (bs x) (λ y → g y ∶ C (f y)) ⇒ c x f g ∶ C (sup x f))

      → {a : A ．}
      → {f : B a ． → Wᵒ A (B , bs) ．}
      → {Δ₀ : sply ℓ}
      → (Δ₀ ⇒ a ∶ A)
      → Δ₀  ⨾ Δ₁ a ⨾ ⨂ (B a) (bs a) (λ y → elimW {P = λ y → C y ．} c (f y) ∶ C (f y)) ⇒
        c a f (λ y → elimW {P = λ z → C z ．} c (f y))
        -- elimW {P = λ z → C z ．} c (sup a f)
          ∶ C (sup a f)
  compWᵒ δ {a} {f} δ₀ = δ {g = (λ y → elimW {P = λ y → C y ．} c (f y))} ∘ δ₀ ⨾ᶠ id

