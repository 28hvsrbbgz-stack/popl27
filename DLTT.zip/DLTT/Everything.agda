module DLTT.Everything where

-- This artefact accompanies  "Dependent Multiplicities in Dependent Linear Type Theory"

-- The code has been typechecked with Agda in version 2.6.4.3.
-- Apart from the monoidal solver, all files compile with the flag --safe
-- and do not rest on any library

open import DLTT.Prelude

-- Contains the main construction: definition of supply and production types,
-- linear type formers and their elaboration, introduces quantitative features
-- with supply exponentiation
open import DLTT.Base



-- Formalises elaborations of the linear type formers
open import DLTT.Function
open import DLTT.Pair
open import DLTT.Empty
open import DLTT.Unit
open import DLTT.Bool
open import DLTT.W


-- Examples highlighting basic workings of the embedded linear structure
open import DLTT.Examples.Structure

-- Functional programming examples, concluding with substitution function in
-- lambda calculus
open import DLTT.Examples.Maybe
open import DLTT.Examples.List
open import DLTT.Examples.Nat
open import DLTT.Examples.Lambda



-- Tactic with simple monoidal solver to resolve basic coercions
-- (requires standard library and not safe since non-terminating reordering)
open import DLTT.ProductionSolver
